# CIFAR-10-images
CIFAR-10 raw jpeg images

You can just clone this repository to use dataset.
